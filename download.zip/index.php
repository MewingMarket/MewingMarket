<?php
/* Reindirizza alla home page HTML dello store */
include_once("index.html");
?>

